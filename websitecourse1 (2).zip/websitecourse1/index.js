const btn = document.querySelector(".btn")
const video = document.querySelector(".background-video")
const fa=document.querySelector(".fa")
const preloader = document.querySelector(".preloader")
btn.addEventListener("click", ()=>{
 if(btn.classList.contains("rocket")){
     btn.classList.remove("rocket")
    fa.classList.add("fa-rocket")
    fa.classList.remove("fa-play")}
     else{
         bt.classList.add("rocket")
         fa.classList.remove("fa-rocket")
         fa.classList.add("fa-play")}
         

 
})
window.addEventListener("load", ()=>{
    preloader.style.zIndex="-2"
})