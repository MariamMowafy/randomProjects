let num=0

const value = document.querySelector(".value")
const btns = document.querySelectorAll(".btn")
btns.forEach((btn)=>{
    btn.addEventListener("click",(event)=>{
        const styles = event.currentTarget.classList
        if(styles.contains("btn-danger")){
            if(num>0){
                num--;
            }
        }
        if(styles.contains("btn-success")){
            num++;
        }
        if(styles.contains("btn-warning")){
            num=0;
        }
        value.textContent=num;
        if(num%2==0){
            value.style.color="blue"
        }
        else{
            value.style.color="green"
        }
    })
})